Generator zaswiadczen offline V27 - wersja Windows

Jak uruchomic:
1. Rozpakuj caly folder ZIP.
2. Otworz plik "Uruchom generator.bat".
3. Generator uruchomi sie w domyslnej przegladarce, np. Microsoft Edge lub Chrome.

Wazne:
- Nie przenos samego pliku index.html bez pliku panel_logo_lm_transparent.png.
- Generator dziala lokalnie/offline w przegladarce.
- Wygenerowane pliki PDF/CSV beda pobierane przez przegladarke zgodnie z jej ustawieniami.
